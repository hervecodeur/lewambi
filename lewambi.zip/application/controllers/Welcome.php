<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	  public function __construct(){
   	parent::__construct();
   	$this->load->library('layout');
   	$this->load->model('propriete_model');
   }
	public function Layout(){
		$this->layout->view('propriete/form_propriete');
	}
	public function index()
	{
		$this->layout->view('administrator');
	}

	// liste des utilisateurs

	public function list_users(){
	$data = $this->propriete_model->get_all('sf_guard_user');
     $this->layout->view('users/users', array('list'=> $data));
		//var_dump($data);
		
	}

	// liste des villes
	public function liste_villes(){
	$data = $this->propriete_model->get_all('ville');
     $this->layout->view('ville', array('list'=> $data));
		//var_dump($data);
		
	}

	// liste des region
	public function liste_region()
	{$data = $this->propriete_model->get_all('region');
	     $this->layout->view('region', array('list'=> $data));
			//var_dump($data);
	 }
		
		// liste des pays
	public function liste_pays(){
	$data = $this->propriete_model->get_all('pays');
     $this->layout->view('pays', array('list'=> $data));
		//var_dump($data);
		
	}

}
