<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class investissement extends CI_Controller {

	  public function __construct(){
   	parent::__construct();
   	$this->load->library('layout');
   	$this->load->model('propriete_model');
   }
	
	public function index()
	{
		$this->layout->view('investissement/add_type');
	}

	// liste des utilisateurs

	public function list_users(){
	$data = $this->propriete_model->get_all('sf_guard_user');
     $this->layout->view('users/users', array('list'=> $data));
		//var_dump($data);
		
	}
}
