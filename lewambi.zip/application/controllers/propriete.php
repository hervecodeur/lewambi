<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Propriete extends CI_Controller {

   public function __construct(){
   	parent::__construct();
   	$this->load->library('layout');
   }

	public function index()
		{
			$data = $this->liste_categorie();
			$agents = $this->liste_agent();
			$ville = $this->propriete_model->get_all('ville');
			$region = $this->propriete_model->get_all('region');
			$pays = $this->propriete_model->get_all('pays');
			$type = $this->propriete_model->get_all('type_categorie');
			$feature = $this->propriete_model->get_all('feature');
			$this->layout->view('propriete/form_propriete', array('list'=> $data, 
				'agent'=> $agents, 
				'ville'=> $ville, 
				'region'=> $region,
				'type'=> $type, 
				'feature'=> $feature, 
				'pays'=> $pays));
				//var_dump($data);
		}
	
	public function liste_categorie(){
		$this->load->model('propriete_model');
		$data = $this->propriete_model->get_all('categorie');
		return $data;
		//var_dump($data);
	}
	public function test(){
		$this->liste_categorie();
		var_dump($list);
	}

	// liste des agents commerciaux
	public function liste_agent(){
	$agents = $this->propriete_model->get_all('agent_immobilier');
	return $agents;
	}
}
