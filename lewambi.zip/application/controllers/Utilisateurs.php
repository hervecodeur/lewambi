<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Utilisateurs extends CI_Controller {

	  public function __construct(){
   	parent::__construct();
   	$this->load->library('layout');
   	$this->load->model('propriete_model');
   }
	
	public function index()
	{
		$this->layout->view('services-a-domicile/add_service');
	}

	// liste des utilisateurs

	public function users_group(){
	$data = $this->propriete_model->get_all('sf_guard_group');
     $this->layout->view('users/users_group', array('list'=> $data));
		//var_dump($data);
		
	}
}
