 <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?= base_url()?>assets/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Alexander Pierce</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MENU DE NAVIGATION</li>
        <li><a href="https://adminlte.io/docs"><i class="fa fa-home"></i> <span>Accueil</span></a></li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i>
            <span>Tableau de bord</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right">8</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/layout/top-nav.html"><i class="fa fa-users"></i> Gestion des utilisateurs</a></li>
            <li><a href="pages/layout/boxed.html"><i class="fa fa-circle-o"></i> Gestion des blacklistages</a></li>
            <li><a href="pages/layout/top-nav.html"><i class="fa fa-group "></i> Gestion des groupes</a></li>
            <li><a href="pages/layout/boxed.html"><i class="fa fa-key"></i> Gestion des permissions</a></li>
            <li><a href="pages/layout/top-nav.html"><i class="fa fa-comment"></i> Gestion des témoignages</a></li>
            <li><a href="pages/layout/boxed.html"><i class="fa fa-question"></i> Gestion des faqs</a></li>
            <li><a href="pages/layout/top-nav.html"><i class="fa fa-circle-o"></i> Gestion des déménagements</a></li>
            <li><a href="pages/layout/boxed.html"><i class="fa fa-circle-o"></i> Gestion des agents immobiliers</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-mortar-board"></i>
            <span>Gestion des promotion</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right">4</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/layout/top-nav.html"><i class="fa fa-circle-o"></i> Gestion des comptes Agents</a></li>
            <li><a href="pages/layout/boxed.html"><i class="fa fa-circle-o"></i> Gestion des promotion</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-car"></i>
            <span>Services à domicile</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/charts/chartjs.html"><i class="fa fa-plus-circle"></i> Ajouter une catégorie </a></li>
            <li><a href="pages/charts/morris.html"><i class="fa fa-circle-o"></i> Gérer les déménageurs</a></li>
            <li><a href="pages/charts/morris.html"><i class="fa fa-circle-o"></i> Gérer les déménagements</a></li>
            <li><a href="pages/charts/flot.html"><i class="fa fa-circle-o"></i> Gérer les dévis</a></li>
            <li><a href="pages/charts/flot.html"><i class="fa fa-circle-o"></i> Gestion des Nousnous</a></li>
            <li><a href="pages/charts/flot.html"><i class="fa fa-circle-o"></i> Gestion des Ménagères</a></li>
            <li><a href="pages/charts/flot.html"><i class="fa fa-circle-o"></i> Gestion des Peintres</a></li>
            <li><a href="pages/charts/flot.html"><i class="fa fa-circle-o"></i> Gestion des éléctriciens</a></li>
            <li><a href="pages/charts/flot.html"><i class="fa fa-circle-o"></i> Gestion des décorateurs</a></li>
            <li><a href="pages/charts/flot.html"><i class="fa fa-circle-o"></i> Gestion des Macons</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-map"></i>
            <span>Les bons coins</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/charts/chartjs.html"><i class="fa fa-plus-circle"></i> Ajouter</a></li>
            <li><a href="pages/charts/chartjs.html"><i class="fa fa-plus-circle"></i> Ajouter une catégorie</a></li>
            <li><a href="pages/charts/morris.html"><i class="fa fa-circle-o"></i> Consulter les bon coins</a></li>
            <li><a href="pages/charts/flot.html"><i class="fa fa-circle-o"></i> Gestion des bon coins</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dollar"></i>
            <span>Projet d'investissement</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/charts/chartjs.html"><i class="fa fa-bed"></i> Ajouter un projet</a></li>
             <li><a href="pages/charts/chartjs.html"><i class="fa fa-plus-circle"></i> Ajouter un type de projet</a></li>
            <li><a href="pages/charts/morris.html"><i class="fa fa-circle-o"></i> Consulter les Projets</a></li>
            <li><a href="pages/charts/flot.html"><i class="fa fa-circle-o"></i> Gestion des projets</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-cubes"></i>
            <span>Gestion des annonces</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/UI/general.html"><i class="fa fa-list"></i> Liste des annonces</a></li>
            <li><a href="pages/UI/icons.html"><i class="fa fa-circle-o"></i> Publier des annonces</a></li>
            <li><a href="pages/UI/buttons.html"><i class="fa fa-dollar"></i> Gestion paiement agents</a></li>
            <li><a href="pages/UI/sliders.html"><i class="fa fa-list"></i> Liste des fonctionnalités</a></li>
            <li><a href="pages/UI/timeline.html"><i class="fa fa-plus-circle"></i> Ajouetr une fonctionnalité</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-map-marker"></i> <span>Régionalisation</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/forms/general.html"><i class="fa fa-flag-checkered"></i>  Pays</a></li>
            <li><a href="pages/forms/advanced.html"><i class="fa fa-circle-o"></i> Région </a></li>
            <li><a href="pages/forms/editors.html"><i class="fa fa-circle-o"></i> Ville</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-cog"></i> <span>Gestion des paramètres</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/tables/simple.html"><i class="fa fa-plus-circle"></i>  Ajouter</a></li>
            <li><a href="pages/tables/data.html"><i class="fa fa-search-plus"></i>  Consulter</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-bookmark"></i> <span>Gestion des catégories</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/examples/invoice.html"><i class="fa fa-plus-circle"></i> Ajouter</a></li>
            <li><a href="pages/examples/profile.html"><i class="fa fa-search-plus"></i> Consulter</a></li>
            <li><a href="pages/examples/login.html"><i class="fa fa-search-plus"></i> Consulter un type</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-wrench"></i> <span>Gestion des Propriétes</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/tables/simple.html"><i class="fa fa-plus-circle"></i>  Ajouter</a></li>
            <li><a href="pages/tables/data.html"><i class="fa fa-search-plus"></i>  Consulter</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-info"></i> <span>Informations</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/tables/simple.html"><i class="fa fa-plus-circle"></i>  Messages</a></li>
            <li><a href="pages/tables/data.html"><i class="fa fa-comments"></i>  Newsletter</a></li>
            <li><a href="pages/tables/data.html"><i class="fa fa-comments"></i>  Commentaires</a></li>
          </ul>
        </li>
        <li><a href="https://adminlte.io/docs"><i class="fa fa-info"></i> <span>A propos</span></a></li>
        <
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
