
<?php
include('parts/header.php');
include('parts/sidebar_left.php');
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Tableau de bord
        <small>Gestion des utilisateurs</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
        <li class="active">Gestion des utilisateurs</li>
      </ol>
    </section>

			    <!-- Main content -->
	<section class="content">
		<div class="box box-info">
			<div class="box-header">
				<h3 class="box-tiltle">Consulter La liste des utilisateurs</h3>
			</div>
			<div class="box-body">
			<?php 
			foreach($css_files as $file): ?>
			    <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
			 
			<?php endforeach; ?>
			<?php foreach($js_files as $file): ?>
			 
			    <script src="<?php echo $file; ?>"></script>
			<?php endforeach; ?>
			<!--main content start-->
			
								<div class="table-responsive">
									<?php echo $output; ?>
								</div>
								
						  </div>
						</div>
		
	</section>
</div>
<?php
include('parts/footer.php');
?>