
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    
      <h4>  </h4>
      
    <section class="content-header">
      <h1>
        Regionalisation
        <small>Lewambi</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Accueil</a></li>
        <li><a href="#">Ville</a></li>
        <li class="active">liste</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
        
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Ville</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <a class="btn btn-app bg-olive">
                <i class="fa fa-plus"></i> Ajouter
              </a>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Code</th>
                  <th>Nom(s)</th>
                  <th>Description</th>
                  <th>Is active</th>
                  <th>Region</th>
                  <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                  <?php if ($list != Null): $i = 0 ?>
                  <?php foreach ($list as $user => $value): ?>
                <tr>
                  <td><?php echo $list[$i]->code ;?></td>
                  <td><?php echo $list[$i]->nom ;?></td>
                  <td><?php echo $list[$i]->description ;?></td>
                  <td><?php if ($list[$i]->is_active == 1): ;?> <i class="fa fa-check-square text-success"></i> 
                   <?php else: ;?>
                    <i class="fa fa-times-circle text-danger"></i>
                  <?php endif ;?>
                  </td>
                  <td><?php echo $list[$i]->region_id ;?></td>
                  <td><?php echo $list[$i]->id ;?></td>
                </tr>
                <?php $i = $i +1 ?>
               <?php endforeach; ?>
             <?php endif; ?>
                </tbody>
                <tfoot>
                <tr>
                   <th>Prenom</th>
                  <th>Nom(s)</th>
                  <th>Email</th>
                  <th>Is active</th>
                  <th>Region</th>
                  <th>Actions</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->