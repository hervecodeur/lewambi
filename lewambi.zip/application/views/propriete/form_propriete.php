 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Nouvelle propiété
        <small>Ajout</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Accueil</a></li>
        <li><a href="#">Nouvelle propriété</a></li>
        <li class="active">Ajout</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Choisir</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form">
              <div class="box-body">
                  <div class="form-group">
                  <label>Agent immobilier</label>
                  <select class="form-control select2" style="width: 100%;">
                  <?php if ($agent != NULL): $i = 0?>
                  <?php  foreach ($agent as $key => $value ): ?>
                  <option value="<?php echo $agent[$i]->nom ;?>"><?php echo $agent[$i]->nom ;?></option>
                      <?php $i = $i +1 ;?>
                     <?php endforeach ;?>
                     <?php endif ;?>
                </select>
                </div>
                  <div class="form-group">
                  <label>Catégorie</label>
                  <select class="form-control" name="categorie">
                     <?php if ($list != NULL): $i = 0?>
                      <?php  foreach ($list as $cat => $value ): ?>
                      <option value="<?php echo $list[$i]->nom ;?>"><?php echo $list[$i]->nom ;?></option>
                      <?php $i = $i +1 ;?>
                     <?php endforeach ;?>
                     <?php endif ;?>
                     
                  </select>
                </div>
                  <div class="form-group">
                  <label>Nature</label>
                  <select class="form-control">
                    <?php if ($type != NULL): $i = 0?>
                      <?php  foreach ($type as $key => $value ): ?>
                      <option value="<?php echo $type[$i]->nom ;?>"><?php echo $type[$i]->nom ;?></option>
                      <?php $i = $i +1 ;?>
                     <?php endforeach ;?>
                     <?php endif ;?>
                  </select>
                </div>
                  <div class="form-group">
                  <label>Ville</label>
                  <select class="form-control select2" style="width: 100%;">
                  <?php if ($ville != NULL): $i = 0?>
                      <?php  foreach ($ville as $key => $value ): ?>
                      <option value="<?php echo $ville[$i]->nom ;?>"><?php echo $ville[$i]->nom ;?></option>
                      <?php $i = $i +1 ;?>
                     <?php endforeach ;?>
                     <?php endif ;?>
                </select>
                </div>
                  <div class="form-group">
                  <label>Region</label>
                  <select class="form-control">
                    <?php if ($region != NULL): $i = 0?>
                      <?php  foreach ($region as $key => $value ): ?>
                      <option value="<?php echo $region[$i]->nom ;?>"><?php echo $region[$i]->nom ;?></option>
                      <?php $i = $i +1 ;?>
                     <?php endforeach ;?>
                     <?php endif ;?>
                  </select>
                </div>
                  <div class="form-group">
                  <label>Pays</label>
                  <select class="form-control">
                    <?php if ($pays != NULL): $i = 0?>
                      <?php  foreach ($pays as $key => $value ): ?>
                      <option value="<?php echo $pays[$i]->nom ;?>"><?php echo $pays[$i]->nom ;?></option>
                      <?php $i = $i +1 ;?>
                     <?php endforeach ;?>
                     <?php endif ;?>
                  </select>
                </div>
                  <div class="form-group">
                  <label>Type</label>
                  <select class="form-control">
                   <option value="Vendre ou louer ">Vendre ou louer </option>
                    <option value="Vendre">Vendre</option>
                    <option value="Louer">Louer</option>
                  </select>
                </div>
                  <div class="form-group">
                  <label>Paiement</label>
                  <select class="form-control">
                    <option value="" selected="selected">Periode</option>
                      <option value="21">Par An</option>
                      <option value="22">Par Mois</option>
                      <option value="23">Par Six Mois</option>
                      <option value="24">Jour </option>
                      <option value="25">Par M2</option>
                  </select>
                </div>
                  <div class="form-group">
                  <label>Nature prix</label>
                  <select class="form-control">
                    <option value="" selected="selected">Type de prix</option>
                    <option value="4">Non negociable  </option>
                    <option value="5">negociable  </option>
                  </select>
                </div>

                <div class="form-group">
                  <div class="col-sm-offset-2 col-sm-10">
                    <div class="checkbox">
                      <label>
                        <input type="checkbox"> Rendre actif
                      </label>
                    </div>
                    <div class="checkbox">
                      <label>
                        <input type="checkbox"> Rendre premium
                      </label>
                    </div><div class="checkbox">
                      <label>
                        <input type="checkbox"> Est publicité
                      </label>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                <label>Fonctionnalité Supplementaires</label>
                <select class="form-control select2" multiple="multiple" data-placeholder="Selectionner la fonctionnalités"
                        style="width: 95%;">
                  <?php if ($feature != NULL): $i = 0?>
                      <?php  foreach ($feature as $key => $value ): ?>
                      <option value="<?php echo $feature[$i]->nom ;?>"><?php echo $feature[$i]->nom ;?></option>
                      <?php $i = $i +1 ;?>
                     <?php endforeach ;?>
                     <?php endif ;?>
                </select>
              </div>
              </div>
              <div class="form-group ">
                  <label>Description du bien</label>
                  <textarea class="form-control" rows="3" placeholder="Entrer ..."></textarea>
                </div>
              <!-- /.box-body -->

              <div class="box-footer">
                
              </div>
            </form>
          </div>
          <!-- /.box -->

        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Entrez les valeurs</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal">
              <div class="box-body">
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-6 control-label">Nombre de chambres</label>

                  <div class="col-sm-6">
                    <input type="number" class="form-control" id="inputEmail3" placeholder="Nombre de chambres">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-6 control-label">Nombre de douches</label>

                  <div class="col-sm-6">
                    <input type="number" class="form-control" id="inputEmail3" placeholder="Nombre de douches">
                  </div>
                </div>
              <div class="form-group">
                  <label for="inputEmail3" class="col-sm-6 control-label">Distance de la routes</label>

                  <div class="col-sm-6">
                    <input type="number" class="form-control" id="inputEmail3" placeholder="En Km">
                  </div>
                </div>
              <div class="form-group">
                  <label for="inputEmail3" class="col-sm-6 control-label">Superficie</label>

                  <div class="col-sm-6">
                    <input type="number" class="form-control" id="inputEmail3" placeholder="Superficie">
                  </div>
                </div>
               <div class="form-group">
                  <label for="inputEmail3" class="col-sm-6 control-label">Nombre de places</label>

                  <div class="col-sm-6">
                    <input type="number" class="form-control" id="inputEmail3" placeholder="Nombre de places">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-6 control-label">Prix</label>

                  <div class="col-sm-6">
                    <input type="number" class="form-control" id="inputEmail3" placeholder="Prix">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-6 control-label">Lien video</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" id="inputEmail3" placeholder="votre lien">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-6 control-label">Quartier</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" id="inputEmail3" placeholder="Quartier">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-6 control-label">Quartier environnant</label>

                  <div class="col-sm-6">
                    <input type="email" class="form-control" id="inputEmail3" placeholder="Separez par des virgules">
                  </div>
                </div>
                <!-- textarea -->
                 
                <div class="form-group col-sm-10">
                  <label for="exampleInputFile">Photo salon</label>
                  <input type="file" id="exampleInputFile">
                </div>
                <div class="form-group col-sm-10">
                  <label for="exampleInputFile">Photo devanture</label>
                  <input type="file" id="exampleInputFile">
                </div>
                <div class="form-group col-sm-10">
                  <label for="exampleInputFile">¨Photo cuisine</label>
                  <input type="file" id="exampleInputFile">
                </div>
                <div class="form-group col-sm-10">
                  <label for="exampleInputFile">Photo douche</label>
                  <input type="file" id="exampleInputFile">
                </div>
                <div class="form-group col-sm-10">
                  <label for="exampleInputFile">Photo plafond</label>
                  <input type="file" id="exampleInputFile">
                </div>
                <div class="form-group col-sm-10">
                  <label for="exampleInputFile">Photo sol</label>
                  <input type="file" id="exampleInputFile">
                </div>
                
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="reset" class="btn btn-danger">Annuler</button>
                <button type="submit" class="btn btn-info pull-right">Enregistrer</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
          
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
 